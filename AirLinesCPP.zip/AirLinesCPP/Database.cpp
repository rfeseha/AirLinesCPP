#include"pch.h"
#include "Database.h"
#include <iostream>
#include <stdexcept>

using namespace std;

namespace AirLinesApp
{

    PassengerInfo& Database::addPassenger(const std::string& firstName,
		const std::string& lastName, const std::string& EmailAddress,
		const std::string& Address)
    {
		PassengerInfo PassengerInfo(firstName, lastName, EmailAddress, Address);
		mPassengerInfo.push_back(PassengerInfo);
		return mPassengerInfo[mPassengerInfo.size() -1];
		
	}


    PassengerInfo& Database::getPassengerInfo(const std::string& firstName, const std::string& lastName,
		const std::string EmailAddress, const std::string& Address)
	{


		for (auto& PassengerInfo : mPassengerInfo)
	    {
			if (PassengerInfo.getFirstName() == firstName &&
				PassengerInfo.getLastName() == lastName &&
				PassengerInfo.getEmailAddress() == EmailAddress &&
				PassengerInfo.getAddress() == Address)
			{

				return PassengerInfo;
			}
		}

		throw logic_error("No passenger found.");
	}

    Flight& Database::addFlight(const std::string & firstName, const std::string& lastName, const std::string& DepartureCity, const std::string& DestinationCity,
		const std::string& DepartureDate, const std::string& ArrivalDate)
	{

	           Flight Flight(firstName, lastName, DepartureCity, DestinationCity, DepartureDate, ArrivalDate);
			   mFlight.push_back(Flight);
			   return mFlight[mFlight.size() - 1];
	}

    Flight& Database::getFlight(const std::string& firstName, const std::string& lastName, const std::string& DepartureCity, const std::string& DestinationCity,
		const std::string& DepartureDate, const std::string& ArrivalDate)
	{
		for (auto& Flight : mFlight)
		{ 
			if (Flight.getFirstName() ==firstName &&
				Flight.getLastName() == lastName &&
				Flight.getDepartureCity() == DepartureCity &&
				Flight.getDestinationCity() == DestinationCity &&
				Flight.getDepartureDate() == DepartureDate &&
				Flight.getArrivalDate() == ArrivalDate) 
			{

				return Flight; 
			}

		}

		throw logic_error("Flight is Not Found");
	}

	void Database::DisplayTicketInfo() const
	{
		for (const auto& PassengerInfo : mPassengerInfo)
		{

			PassengerInfo.DisplayInfo();

		}

		for (const auto& Flight : mFlight)
		{

			Flight.FlightInfo();
		}

    }



    void Database::DisplayInfo() const
	{

		for (const auto& PassengerInfo: mPassengerInfo )
		{

			PassengerInfo.DisplayInfo();

		}
	}
    void Database::FlightInfo() const
{
		for (const auto& Flight: mFlight)
		{

			Flight.FlightInfo();
		}
}
	
	
}

