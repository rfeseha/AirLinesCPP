#include "pch.h"
#include  <iostream>
#include "AirLines.h"
#include <string>

using namespace std;

namespace AirLinesApp
{
	PassengerInfo::PassengerInfo(const std::string& firstName,
		const std::string& lastName, const std::string& EmailAddress,
		const std::string& Address) :mFirstName(firstName), mLastName(lastName), mAddress(Address),
		mEmailAddress(EmailAddress) {}

	void PassengerInfo::setFirstName(const std::string& firstName)
	{
		mFirstName = firstName;
	}
	const string& PassengerInfo::getFirstName() const
	{
		return mFirstName;
	}
	void PassengerInfo::setLastName(const std::string& lastName)
	{
		mLastName = lastName;
	}
	const string& PassengerInfo::getLastName() const
	{
		return mLastName;
	}
	void PassengerInfo::setEmailAddress(const std::string& EmailAddress)
	{
		mEmailAddress = EmailAddress;
	}
	const string& PassengerInfo::getEmailAddress() const
	{
		return mEmailAddress;
	}
	void PassengerInfo::setAddress(const std::string& Address)
	{
		mAddress = Address;
	}
	const string& PassengerInfo::getAddress() const
	{
		return mAddress;
	}


	void PassengerInfo::DisplayInfo() const
	{
		cout << "\t\t\t\t  Name: " <<getFirstName() <<getLastName()  << endl;
		cout << "\t\t\t\t  Email:" << getEmailAddress() << ", "  "Address : " << getAddress()  << ", " << endl;
		cout << "------------------------------------------------------------=-" << endl;
	}

	Flight::Flight(const std::string& firstName, const std::string& lastName, const std::string& DepartureCity, const std::string& DestinationCity,
		const std::string& DepartureDate, const std::string& ArrivalDate)
		:mFirstName(firstName), mLastName(lastName), mDepartureCity(DepartureCity), mDestinationCity(DestinationCity),
		mDepartureDate(DepartureDate), mArrivalDate(ArrivalDate)
	{

	}
	void Flight::setFirstName(const std::string& firstName)
	{
		mFirstName = firstName;
	}
	const string& Flight::getFirstName() const
	{
		return mFirstName;
	}
	void Flight::setLastName(const std::string& lastName)
	{
		mLastName = lastName;
	}
	const string& Flight::getLastName() const
	{
		return mLastName;
	}

	void Flight::setDepartureDate(const std::string& DepartureDate)
	{
		DepartureDate;
	}

	const std::string& Flight::getDepartureDate() const
	{
		 return mDepartureDate;
	}

	void Flight::setArrivalDate(const std::string& ArrivalDate)
	{
		mArrivalDate;
	}

	const std::string& Flight::getArrivalDate() const
	{
		return mArrivalDate;
	}

	void Flight::setDestinationCity(const string& DestinationCity)
	{
		mDestinationCity = DestinationCity;
	}

	const std::string& Flight::getDestinationCity() const
	{
		return mDestinationCity;
	}

	void Flight::setDepartureCity(const string& DepartureCity)
	{
		mDepartureCity = DepartureCity;

	}

	const std::string& Flight::getDepartureCity() const
	{

		return mDepartureCity;
	}

	void Flight::ReserveSeat()
	{

	}

	void Flight::DisplayTicketInfo() const
	{
		cout << "--------------------------------------------------------------------------------------------------------------------" << endl;
		cout << "Name: " << getFirstName() << getLastName() << endl;
		cout << " Departure Date: " << getDepartureDate() << "Arrival Date: " << getArrivalDate() << endl;
		cout << "DepartureCity: " << getDepartureCity() << "DestinationCity: " << getDestinationCity() << endl;
		cout << "=======================================================================================================================================" << endl;
	}

	void Flight::FlightInfo() const
	{

	cout << " ----------------------------------------FlightInfo------------------------------------------------------------------------------------------------- " << endl;
	cout << " Departure Date: " << getDepartureDate() << "Arrival Date: " << getArrivalDate() << endl;
	cout << "DepartureCity: " << getDepartureCity() << "DestinationCity: " << getDestinationCity() << endl;
	cout << "--------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;

	}
}

