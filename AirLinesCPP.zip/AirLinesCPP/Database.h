#pragma once
#include <iostream>
#include <vector>
#include "AirLines.h"

namespace AirLinesApp
{
	class Database
	{
	public:
		PassengerInfo& addPassenger(const std::string& firstName,
			const std::string& lastName, const std::string& EmailAddress,
			const std::string& Address);
		PassengerInfo& getPassengerInfo(const std::string& firstName, const std::string& lastName,
				const std::string EmailAddress, const std::string& Address);
		
		Flight& addFlight(const std::string & firstName, const std::string& lastName, const std::string& DepartureCity, const std::string& DestinationCity,
				const std::string& DepartureDate, const std::string& ArrivalDate);
		Flight& getFlight(const std::string& firstName, const std::string& lastName,const std::string& DepartureCity, const std::string& DestinationCity,
			const std::string& DepartureDate, const std::string& ArrivalDate);
		
		void DisplayInfo() const;
		void FlightInfo() const;
		void DisplayTicketInfo() const;
		



	private:
		std::vector<PassengerInfo> mPassengerInfo;
		std::vector<Flight> mFlight;


			
	};


}