#pragma once
#include<string>

namespace AirLinesApp
{
	class PassengerInfo
	{
	public:
		PassengerInfo() = default;
		PassengerInfo(const std::string& firstName,
			const std::string& lastName, const std::string& EmailAddress,
			const std::string& Address);


		void DisplayInfo() const;

		void setFirstName(const std::string& firstName);
		const std::string& getFirstName() const;

		void setLastName(const std::string& lastName);
		const std::string& getLastName() const;

		void setEmailAddress(const std::string& EmailAddress);
		const std::string& getEmailAddress() const;

		void setAddress(const std::string& Address);
		const std::string& getAddress() const;

	private:
		std::string mFirstName;
		std::string mLastName;
		std::string mEmailAddress;
		std::string mAddress;
		

	};
class Flight
{
public:
	Flight() = default;
	Flight(const std::string& firstName, const std::string& lastName, const std::string& DepartureCity, const std::string& DestinationCity, 
		const std::string& DepartureDate, const std::string& ArrivalDate);


	void setFirstName(const std::string& firstName);
	const std::string& getFirstName() const;

	void setLastName(const std::string& lastName);
	const std::string& getLastName() const;

	const std::string& getDepartureCity()const;
	void setDepartureCity(const std::string& DepartureCity);

	const std::string& getDestinationCity() const;
	void setDestinationCity(const std:: string & setDestinationCity);

	const std::string& getDepartureDate() const;
	void setDepartureDate(const std::string& setDepartureDate);

	const std::string& getArrivalDate() const;
	void setArrivalDate(const std::string& setArrivalDate);
	
	void ReserveSeat();
	void DisplayTicketInfo() const;  
	void FlightInfo() const;


private:
	std::string mFirstName;
	std::string mLastName;
	std::string mDepartureDate;
	std::string mArrivalDate;
	std::string mDepartureCity;
	std::string mDestinationCity;
	
};
}



